CREATE TABLE dPaymentMethod(
	PaymentMethodID INT PRIMARY KEY,
	PaymentMethodName VARCHAR(30)
);