--CREATE VIEW dOrderDate AS
--SELECT *
--FROM dDate;

--CREATE VIEW dRequiredDate AS
--SELECT *
--FROM dDate;

--CREATE VIEW dShippedDate AS
--SELECT *
--FROM dDate;

--CREATE VIEW dOrderTime AS
--SELECT *
--FROM dTime;

--CREATE VIEW dRequiredTime AS
--SELECT *
--FROM dTime;

CREATE VIEW dShippedTime AS
SELECT *
FROM dTime;
