SELECT * 
INTO dShippers 
FROM Shippers;